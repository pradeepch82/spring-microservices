package com.pradeep.productservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.pradeep.productservice.dao.ProductRepository;
import com.pradeep.productservice.domain.Product;

@Service
public class ProductServiceImpl implements IProductService{

	@Autowired
	private ProductRepository repository;
	
	@Value("${server.port:1111}")	
	int port;	
		
	
	
	@Override
	public void addProduct(Product product) {
		
		repository.save(product);
		
		
	}

	@Override
	public void updateProduct(Product product) {
		repository.save(product);
			
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
     if(repository.existsById(productId))
    	repository.deleteById(productId);
    
		
	}

	@Override
	public Product findProductById(int productId) {
	
		return repository.findById(productId).get();
	}

	@Override
	public List<Product> findAllProducts() {
		return repository.findAll();
	}
	
	
	@Override
	public String getPort() {
		System.out.println(" ############ In Product Service :"+port+"##############");
		
		return Integer.toString(port);
	}

}
