package com.pradeep.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.DispatcherServlet;

@Controller
public class GreetController {

	public GreetController() {
	System.out.println("GreetController Created");
	}
	

	@RequestMapping("/greet")   //by default  :POST,GET,HEAD
	public String greetingoAll() {
		return "greet";    //   /WEB-INF/views/greet.jsp
	}
	
}
