package com.pradeep.cms.data;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pradeep.cms.domain.Customer;

public enum CustomerMap {

	INSTANCE;
	
private Map<Integer, Customer> map;

private CustomerMap() {
	map=new HashMap<Integer, Customer>();
	
	Customer c1=new Customer("Sachin Chinchole", "amxpx9834d", "87149976542", "Pune", new Date(2009,11,11));
	Customer c2=new Customer("Pradeep Chinchole", "amkxpx9834d", "7149976542", "Mumbai", new Date(2011,11,11));
	Customer c3=new Customer("Mohan Chinchole", "pxxpx9834d", "9149976542", "Pune", new Date(2011,11,11));
	Customer c4=new Customer("Kundan Chinchole", "ddxpx9834d", "777976542", "Banglore", new Date(2000,11,11));
	
	map.put(c1.getCustomerId(),c1);
	map.put(c2.getCustomerId(),c2);
	map.put(c3.getCustomerId(),c3);
	map.put(c4.getCustomerId(),c4);
	
	
}

	public Map<Integer, Customer> getMap() {
		return map;
	}
		
}
