package com.pradeep.consumer.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.pradeep.consumer.fallback.ProductServiceFallback;
import com.pradeep.productservice.domain.Product;

@FeignClient(name="product-service",fallback = ProductServiceFallback.class)
public interface ProductServiceProxy {
	
	@GetMapping(value="/api/product-microservice/products/{id}",produces = {MediaType.APPLICATION_JSON_VALUE})
	Product findProductById(@PathVariable("id")int productId);
	

	@GetMapping(value="/api/product-microservice/products",produces = {MediaType.APPLICATION_JSON_VALUE})
	List<Product> findAllProducts();
	
	
	@GetMapping(value="/api/product-microservice",produces = {MediaType.TEXT_PLAIN_VALUE})
	String getPort();
		
}
